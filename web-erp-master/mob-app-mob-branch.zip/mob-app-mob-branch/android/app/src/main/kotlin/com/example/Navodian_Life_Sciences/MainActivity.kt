package com.example.Navodian_Life_Sciences

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
